# Spelic

Class group project for Software Development
