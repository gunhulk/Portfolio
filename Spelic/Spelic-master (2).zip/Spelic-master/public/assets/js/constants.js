// Account Types
const ACCOUNT_TYPE_TEACHER = "teacher";
const ACCOUNT_TYPE_STUDENT = "student";

// Grades
const FIRST_GRADE = 1;
const SECOND_GRADE = 2;
const THIRD_GRADE = 3;
const FOURTH_GRADE = 4;
const FIFTH_GRADE = 5;
